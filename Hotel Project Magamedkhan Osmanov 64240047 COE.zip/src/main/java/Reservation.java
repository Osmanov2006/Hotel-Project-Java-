import java.time.LocalDate;

public class Reservation{
    private int roomNumber;
    private Customer customer;
    private LocalDate startDate;
    private LocalDate endDate;

    public Reservation(int roomNumber,Customer customer,LocalDate startDate,LocalDate endDate){
        this.roomNumber=roomNumber;
        this.customer=customer;
        this.startDate=startDate;
        this.endDate=endDate;
    }

    public int getRoomNumber(){
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber){
        this.roomNumber=roomNumber;
    }

    public Customer getCustomer(){
        return customer;
    }

    public void setCustomer(Customer customer){
        this.customer=customer;
    }

    public LocalDate getStartDate(){
        return startDate;
    }

    public void setStartDate(LocalDate startDate){
        this.startDate=startDate;
    }

    public LocalDate getEndDate(){
        return endDate;
    }

    public void setEndDate(LocalDate endDate){
        this.endDate=endDate;
    }

    public boolean overlaps(LocalDate rangeStart,LocalDate rangeEnd){
        return !startDate.isAfter(rangeEnd) && !endDate.isBefore(rangeStart);
    }
}