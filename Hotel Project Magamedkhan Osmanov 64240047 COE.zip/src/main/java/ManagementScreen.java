import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.time.LocalDate;

public class ManagementScreen{
    private Stage stage;

    public void show(){
        stage=new Stage();
        stage.setTitle("Management Panel");

        TabPane tabPane=new TabPane();

        Tab roomTab=new Tab("Room Management");
        roomTab.setClosable(false);
        roomTab.setContent(createRoomManagement());

        Tab employeeTab=new Tab("Employee Management");
        employeeTab.setClosable(false);
        employeeTab.setContent(createEmployeeManagement());

        Tab reservationTab=new Tab("Reservation Management");
        reservationTab.setClosable(false);
        reservationTab.setContent(createReservationManagement());

        tabPane.getTabs().addAll(roomTab,employeeTab,reservationTab);

        Scene scene=new Scene(tabPane,700,500);
        stage.setScene(scene);
        stage.show();
    }

    private VBox createRoomManagement(){
        VBox box=new VBox(15);
        box.setPadding(new Insets(20));

        Label title=new Label("Add New Room");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid=new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        Label numLabel=new Label("Room Number:");
        TextField numField=new TextField();

        Label typeLabel=new Label("Room Type:");
        ComboBox<String> typeBox=new ComboBox<>();
        typeBox.getItems().addAll("Single","Double","Suite");
        typeBox.setValue("Single");

        Label priceLabel=new Label("Price per Night:");
        TextField priceField=new TextField();

        grid.add(numLabel,0,0);
        grid.add(numField,1,0);
        grid.add(typeLabel,0,1);
        grid.add(typeBox,1,1);
        grid.add(priceLabel,0,2);
        grid.add(priceField,1,2);

        Button addBtn=new Button("Add Room");
        addBtn.setOnAction(e->{
            try{
                int num=Integer.parseInt(numField.getText());
                String type=typeBox.getValue();
                double price=Double.parseDouble(priceField.getText());

                Room room=new Room(num,type,price);
                DataManager.getInstance().addRoom(room);

                showInfo("Success","Room added successfully");
                numField.clear();
                priceField.clear();
            }catch(Exception ex){
                showAlert("Error","Invalid input. Please check all fields.");
            }
        });

        box.getChildren().addAll(title,grid,addBtn);
        return box;
    }

    private VBox createEmployeeManagement(){
        VBox box=new VBox(15);
        box.setPadding(new Insets(20));

        Label title=new Label("Add New Employee");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid=new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        Label nameLabel=new Label("Name:");
        TextField nameField=new TextField();

        Label phoneLabel=new Label("Phone:");
        TextField phoneField=new TextField();

        Label emailLabel=new Label("Email:");
        TextField emailField=new TextField();

        Label userLabel=new Label("Username:");
        TextField userField=new TextField();

        Label passLabel=new Label("Password:");
        TextField passField=new TextField();

        Label posLabel=new Label("Position:");
        TextField posField=new TextField();

        grid.add(nameLabel,0,0);
        grid.add(nameField,1,0);
        grid.add(phoneLabel,0,1);
        grid.add(phoneField,1,1);
        grid.add(emailLabel,0,2);
        grid.add(emailField,1,2);
        grid.add(userLabel,0,3);
        grid.add(userField,1,3);
        grid.add(passLabel,0,4);
        grid.add(passField,1,4);
        grid.add(posLabel,0,5);
        grid.add(posField,1,5);

        Button addBtn=new Button("Add Employee");
        addBtn.setOnAction(e->{
            if(nameField.getText().isEmpty() || userField.getText().isEmpty()){
                showAlert("Error","Name and username are required");
                return;
            }

            Employee emp=new Employee(nameField.getText(),phoneField.getText(),
                    emailField.getText(),userField.getText(),passField.getText(),
                    posField.getText());
            DataManager.getInstance().addEmployee(emp);

            showInfo("Success","Employee added successfully");
            nameField.clear();
            phoneField.clear();
            emailField.clear();
            userField.clear();
            passField.clear();
            posField.clear();
        });

        box.getChildren().addAll(title,grid,addBtn);
        return box;
    }

    private VBox createReservationManagement(){
        VBox box=new VBox(15);
        box.setPadding(new Insets(20));

        Label title=new Label("Add New Reservation");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid=new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        Label roomLabel=new Label("Room Number:");
        TextField roomField=new TextField();

        Label nameLabel=new Label("Customer Name:");
        TextField nameField=new TextField();

        Label phoneLabel=new Label("Phone:");
        TextField phoneField=new TextField();

        Label emailLabel=new Label("Email:");
        TextField emailField=new TextField();

        Label idLabel=new Label("Customer ID:");
        TextField idField=new TextField();

        Label checkInLabel=new Label("Customer Check-in:");
        DatePicker checkInPicker=new DatePicker(LocalDate.now());

        Label checkOutLabel=new Label("Customer Check-out:");
        DatePicker checkOutPicker=new DatePicker(LocalDate.now().plusDays(1));

        Label startLabel=new Label("Reservation Start:");
        DatePicker startPicker=new DatePicker(LocalDate.now());

        Label endLabel=new Label("Reservation End:");
        DatePicker endPicker=new DatePicker(LocalDate.now().plusDays(1));

        grid.add(roomLabel,0,0);
        grid.add(roomField,1,0);
        grid.add(nameLabel,0,1);
        grid.add(nameField,1,1);
        grid.add(phoneLabel,0,2);
        grid.add(phoneField,1,2);
        grid.add(emailLabel,0,3);
        grid.add(emailField,1,3);
        grid.add(idLabel,0,4);
        grid.add(idField,1,4);
        grid.add(checkInLabel,0,5);
        grid.add(checkInPicker,1,5);
        grid.add(checkOutLabel,0,6);
        grid.add(checkOutPicker,1,6);
        grid.add(startLabel,0,7);
        grid.add(startPicker,1,7);
        grid.add(endLabel,0,8);
        grid.add(endPicker,1,8);

        Button addBtn=new Button("Add Reservation");
        addBtn.setOnAction(e->{
            try{
                int roomNum=Integer.parseInt(roomField.getText());

                if(nameField.getText().isEmpty() || idField.getText().isEmpty()){
                    showAlert("Error","Name and ID are required");
                    return;
                }

                Customer customer=new Customer(nameField.getText(),phoneField.getText(),
                        emailField.getText(),idField.getText(),
                        checkInPicker.getValue(),checkOutPicker.getValue());

                Reservation reservation=new Reservation(roomNum,customer,
                        startPicker.getValue(),endPicker.getValue());

                DataManager.getInstance().addReservation(reservation);

                showInfo("Success","Reservation added successfully");
                roomField.clear();
                nameField.clear();
                phoneField.clear();
                emailField.clear();
                idField.clear();
            }catch(Exception ex){
                showAlert("Error","Invalid input. Please check all fields.");
            }
        });

        box.getChildren().addAll(title,grid,addBtn);
        return box;
    }

    private void showAlert(String title,String message){
        Alert alert=new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String title,String message){
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}